import { Toaster } from 'sonner'

export function Toast() {
    return <Toaster />
}
