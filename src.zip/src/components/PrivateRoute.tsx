import { useAuth } from '@/user/contexts/auth-context'
import { Navigate, Outlet } from 'react-router-dom'

const PrivateRoute = () => {
    const { isAuthenticated, loading } = useAuth()

    if (loading) return <div>Loading...</div> // hoặc spinner

    return isAuthenticated ? <Outlet /> : <Navigate to="/login" />
}

export default PrivateRoute
