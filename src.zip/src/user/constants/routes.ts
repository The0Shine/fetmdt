// import Home from '../pages/Home'
// import ProductDetail from '../pages/ProductDetail'
// import Cart from '../pages/Cart'

// export const userRoutes = [
//     { href: '', component: Home },
//     { href: 'product/:id', component: ProductDetail },
//     { href: 'cart', component: Cart },
// ]
