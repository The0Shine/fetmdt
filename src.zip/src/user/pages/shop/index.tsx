'use client'

import { useState, useEffect } from 'react'
import { useCart } from '../../contexts/cart-context'
import { getProducts } from '../../../services/apiProduct.service'
import { getCategories } from '../../../services/apiCategory.service'
import ProductFilters from '../home/product/product-filters'
import CategorySidebar from '../category/category-sidebar'
import ProductGrid from '../home/product/product-grid'
import type { Product } from '../../../types/product'
import type { Category } from '../../../types/category'

export default function ShopPage() {
    const { addItem } = useCart()
    const [isLoading, setIsLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)
    const [products, setProducts] = useState<Product[]>([])
    const [categories, setCategories] = useState<Category[]>([])
    const [totalProducts, setTotalProducts] = useState(0)
    const [currentPage, setCurrentPage] = useState(1)
    const [totalPages, setTotalPages] = useState(1)

    // State cho query parameters
    const [categoryParam, setCategoryParam] = useState<string | null>(null)
    const [featuredParam, setFeaturedParam] = useState<boolean | null>(null)
    const [hotParam, setHotParam] = useState<boolean | null>(null)
    const [newParam, setNewParam] = useState<boolean | null>(null)
    const [recommendedParam, setRecommendedParam] = useState<boolean | null>(
        null,
    )

    // State cho bộ lọc
    const [searchTerm, setSearchTerm] = useState('')
    const [priceRange, setPriceRange] = useState<[number, number]>([
        0, 100000000,
    ])
    const [onlyInStock, setOnlyInStock] = useState(false)
    const [sortBy, setSortBy] = useState('featured')
    const [limit, setLimit] = useState(12)

    // Lấy tham số URL khi component mount
    useEffect(() => {
        const params = new URLSearchParams(window.location.search)
        setCategoryParam(params.get('category'))
        setFeaturedParam(params.get('featured') === 'true')
        setHotParam(params.get('hot') === 'true')
        setNewParam(params.get('new') === 'true')
        setRecommendedParam(params.get('recommended') === 'true')

        // Lấy trang hiện tại từ URL nếu có
        const page = params.get('page')
        if (page) {
            setCurrentPage(Number.parseInt(page))
        }
    }, [])

    // Fetch danh mục
    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await getCategories()
                if (response) {
                    setCategories(response.data)
                }
            } catch (err) {
                console.error('Error fetching categories:', err)
            }
        }

        fetchCategories()
    }, [])

    // Fetch sản phẩm khi các tham số thay đổi
    useEffect(() => {
        const fetchProducts = async () => {
            setIsLoading(true)
            setError(null)

            try {
                // Xây dựng tham số truy vấn
                const queryParams: any = {
                    page: currentPage,
                    limit: limit,
                    sort: getSortParam(sortBy),
                }

                // Thêm các tham số lọc
                if (categoryParam) queryParams.category = categoryParam
                if (featuredParam) queryParams.featured = featuredParam
                if (hotParam) queryParams.hot = hotParam
                if (newParam) queryParams.new = newParam
                if (recommendedParam) queryParams.recommended = recommendedParam
                if (searchTerm) queryParams.search = searchTerm
                if (onlyInStock) queryParams.status = 'in-stock'
                if (priceRange[0] > 0) queryParams.minPrice = priceRange[0]
                if (priceRange[1] < 100000000)
                    queryParams.maxPrice = priceRange[1]

                const response = await getProducts(queryParams)

                if (response) {
                    setProducts(response.data)
                    setTotalProducts(response.total)
                    setTotalPages(response.pagination.totalPages)
                } else {
                    setError('Không thể tải sản phẩm. Vui lòng thử lại sau.')
                }
            } catch (err) {
                console.error('Error fetching products:', err)
                setError('Có lỗi xảy ra khi tải dữ liệu. Vui lòng thử lại sau.')
            } finally {
                setIsLoading(false)
            }
        }

        fetchProducts()
    }, [
        currentPage,
        limit,
        sortBy,
        categoryParam,
        featuredParam,
        hotParam,
        newParam,
        recommendedParam,
        searchTerm,
        onlyInStock,
        priceRange,
    ])

    // Chuyển đổi sortBy thành tham số sort cho API
    const getSortParam = (sortValue: string): string => {
        switch (sortValue) {
            case 'price-asc':
                return 'price'
            case 'price-desc':
                return '-price'
            case 'name-asc':
                return 'name'
            case 'name-desc':
                return '-name'
            case 'newest':
                return '-createdAt'
            case 'featured':
            default:
                return 'featured'
        }
    }

    const handleAddToCart = (product: Product) => {
        addItem(product, 1)
    }

    const handleFilterApply = () => {
        // Reset về trang 1 khi áp dụng bộ lọc mới
        setCurrentPage(1)
    }

    const handleFilterReset = () => {
        setSearchTerm('')
        setPriceRange([0, 100000000])
        setOnlyInStock(false)
        setSortBy('featured')
        setCurrentPage(1)
    }

    const handlePageChange = (page: number) => {
        setCurrentPage(page)
        // Cập nhật URL với tham số page mới
        const url = new URL(window.location.href)
        url.searchParams.set('page', page.toString())
        window.history.pushState({}, '', url.toString())
        // Cuộn lên đầu trang
        window.scrollTo(0, 0)
    }

    // Hiển thị trạng thái loading
    if (isLoading && products.length === 0) {
        return (
            <div className="container mx-auto px-8 py-8">
                <div className="flex h-96 items-center justify-center">
                    <div className="text-center">
                        <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-4 border-t-4 border-gray-200 border-t-blue-600"></div>
                        <p className="text-lg text-gray-600">
                            Đang tải sản phẩm...
                        </p>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="container mx-auto px-8 py-8">
            <h1 className="mb-6 text-2xl font-bold text-gray-800">Cửa hàng</h1>

            <ProductFilters
                searchTerm={searchTerm}
                onSearchChange={setSearchTerm}
                priceRange={priceRange}
                onPriceRangeChange={setPriceRange}
                onlyInStock={onlyInStock}
                onInStockChange={setOnlyInStock}
                sortBy={sortBy}
                onSortChange={setSortBy}
                onFilterApply={handleFilterApply}
                onFilterReset={handleFilterReset}
            />

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
                <div className="lg:col-span-1">
                    <CategorySidebar
                        categories={categories}
                        selectedCategory={categoryParam || undefined}
                    />
                </div>

                <div className="lg:col-span-3">
                    {error ? (
                        <div className="rounded-lg bg-red-50 p-6 text-center">
                            <p className="text-lg text-red-600">{error}</p>
                            <button
                                onClick={() => window.location.reload()}
                                className="mt-4 rounded-md bg-red-600 px-4 py-2 text-white hover:bg-red-700"
                            >
                                Thử lại
                            </button>
                        </div>
                    ) : products.length > 0 ? (
                        <>
                            <div className="mb-4 flex items-center justify-between">
                                <p className="text-gray-600">
                                    Hiển thị {(currentPage - 1) * limit + 1}-
                                    {Math.min(
                                        currentPage * limit,
                                        totalProducts,
                                    )}{' '}
                                    trên {totalProducts} sản phẩm
                                </p>
                                {isLoading && (
                                    <div className="h-5 w-5 animate-spin rounded-full border-2 border-t-2 border-gray-300 border-t-blue-600"></div>
                                )}
                            </div>

                            <ProductGrid
                                products={products}
                                onAddToCart={handleAddToCart}
                            />

                            {/* Phân trang */}
                            {totalPages > 1 && (
                                <div className="mt-8 flex justify-center">
                                    <div className="flex space-x-1">
                                        <button
                                            onClick={() =>
                                                handlePageChange(
                                                    Math.max(
                                                        1,
                                                        currentPage - 1,
                                                    ),
                                                )
                                            }
                                            disabled={currentPage === 1}
                                            className="rounded-md border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 disabled:opacity-50"
                                        >
                                            &laquo; Trước
                                        </button>

                                        {Array.from(
                                            { length: totalPages },
                                            (_, i) => i + 1,
                                        )
                                            .filter(
                                                (page) =>
                                                    page === 1 ||
                                                    page === totalPages ||
                                                    (page >= currentPage - 1 &&
                                                        page <=
                                                            currentPage + 1),
                                            )
                                            .map((page, index, array) => {
                                                // Thêm dấu ... nếu có khoảng cách giữa các số trang
                                                if (
                                                    index > 0 &&
                                                    page - array[index - 1] > 1
                                                ) {
                                                    return (
                                                        <span
                                                            key={`ellipsis-${page}`}
                                                            className="flex items-center justify-center rounded-md border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700"
                                                        >
                                                            ...
                                                        </span>
                                                    )
                                                }

                                                return (
                                                    <button
                                                        key={page}
                                                        onClick={() =>
                                                            handlePageChange(
                                                                page,
                                                            )
                                                        }
                                                        className={`rounded-md border px-3 py-2 text-sm font-medium ${
                                                            currentPage === page
                                                                ? 'border-blue-600 bg-blue-600 text-white'
                                                                : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                                                        }`}
                                                    >
                                                        {page}
                                                    </button>
                                                )
                                            })}

                                        <button
                                            onClick={() =>
                                                handlePageChange(
                                                    Math.min(
                                                        totalPages,
                                                        currentPage + 1,
                                                    ),
                                                )
                                            }
                                            disabled={
                                                currentPage === totalPages
                                            }
                                            className="rounded-md border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 disabled:opacity-50"
                                        >
                                            Tiếp &raquo;
                                        </button>
                                    </div>
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="rounded-lg bg-white py-12 text-center shadow-sm">
                            <p className="mb-4 text-gray-500">
                                Không tìm thấy sản phẩm nào phù hợp với bộ lọc.
                            </p>
                            <button
                                onClick={handleFilterReset}
                                className="rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                            >
                                Đặt lại bộ lọc
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
