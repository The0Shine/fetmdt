'use client'

import { useEffect, useState } from 'react'
import { useCart } from '../../contexts/cart-context'
import { getCategories } from '../../../services/apiCategory.service'
import { getProducts } from '../../../services/apiProduct.service'
import CategoryGrid from './components/category-grid'
import HeroBanner from './components/hero-banner'
import ProductSection from './components/product-section'
import SecondaryBanner from './components/secondary-banner'
import { banners } from '../../data/banners'
import type { Product } from '../../../types/product'
import type { Category } from '../../../types/category'

export default function ShopHomePage() {
    const { addItem } = useCart()
    const [isLoading, setIsLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)

    // State cho dữ liệu từ API
    const [featuredProducts, setFeaturedProducts] = useState<Product[]>([])
    const [hotProducts, setHotProducts] = useState<Product[]>([])
    const [newProducts, setNewProducts] = useState<Product[]>([])
    const [recommendedProducts, setRecommendedProducts] = useState<Product[]>(
        [],
    )
    const [categories, setCategories] = useState<Category[]>([])

    // Lấy banner chính
    const mainBanner = banners.find((banner) => banner.position === 'main')

    // Lấy các banner phụ
    const secondaryBanners = banners.filter(
        (banner) => banner.position === 'secondary',
    )

    // Fetch dữ liệu từ API
    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true)
            setError(null)

            try {
                // Fetch danh mục
                const categoriesResponse = await getCategories()
                if (categoriesResponse) {
                    setCategories(categoriesResponse.data)
                }

                // Fetch sản phẩm nổi bật
                const featuredResponse = await getProducts({
                    featured: true,
                    limit: 8,
                })
                if (featuredResponse) {
                    setFeaturedProducts(featuredResponse.data)
                }

                // Fetch sản phẩm hot
                const hotResponse = await getProducts({ hot: true, limit: 8 })
                if (hotResponse) {
                    setHotProducts(hotResponse.data)
                }

                // Fetch sản phẩm mới
                const newResponse = await getProducts({ new: true, limit: 8 })
                if (newResponse) {
                    setNewProducts(newResponse.data)
                }

                // Fetch sản phẩm đề xuất
                const recommendedResponse = await getProducts({
                    recommended: true,
                    limit: 8,
                })
                if (recommendedResponse) {
                    setRecommendedProducts(recommendedResponse.data)
                }
            } catch (err) {
                console.error('Error fetching data:', err)
                setError('Có lỗi xảy ra khi tải dữ liệu. Vui lòng thử lại sau.')
            } finally {
                setIsLoading(false)
            }
        }

        fetchData()
    }, [])

    // Xử lý thêm sản phẩm vào giỏ hàng
    const handleAddToCart = (product: Product) => {
        addItem(product, 1)
    }

    // Hiển thị trạng thái loading
    if (isLoading) {
        return (
            <div className="container mx-auto px-4 py-8">
                <div className="flex h-96 items-center justify-center">
                    <div className="text-center">
                        <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-4 border-t-4 border-gray-200 border-t-blue-600"></div>
                        <p className="text-lg text-gray-600">
                            Đang tải dữ liệu...
                        </p>
                    </div>
                </div>
            </div>
        )
    }

    // Hiển thị lỗi nếu có
    if (error) {
        return (
            <div className="container mx-auto px-4 py-8">
                <div className="rounded-lg bg-red-50 p-6 text-center">
                    <p className="text-lg text-red-600">{error}</p>
                    <button
                        onClick={() => window.location.reload()}
                        className="mt-4 rounded-md bg-red-600 px-4 py-2 text-white hover:bg-red-700"
                    >
                        Thử lại
                    </button>
                </div>
            </div>
        )
    }

    return (
        <div className="container mx-auto px-4 py-8">
            {/* Hero Banner */}
            {mainBanner && (
                <div className="mb-8">
                    <HeroBanner banner={mainBanner} />
                </div>
            )}

            {/* Danh mục sản phẩm */}
            <section className="mb-12">
                <h2 className="mb-6 text-2xl font-bold text-gray-800">
                    Danh mục sản phẩm
                </h2>
                <CategoryGrid categories={categories} />
            </section>

            {/* Sản phẩm nổi bật */}
            {featuredProducts.length > 0 && (
                <ProductSection
                    title="Sản phẩm nổi bật"
                    subtitle="Những sản phẩm được khách hàng yêu thích nhất"
                    products={featuredProducts}
                    viewAllLink="/shop?featured=true"
                    onAddToCart={handleAddToCart}
                />
            )}

            {/* Banner phụ */}
            {secondaryBanners.length > 0 && (
                <div className="mb-12 grid grid-cols-1 gap-6 md:grid-cols-2">
                    {secondaryBanners.map((banner) => (
                        <SecondaryBanner key={banner.id} banner={banner} />
                    ))}
                </div>
            )}

            {/* Sản phẩm hot */}
            {hotProducts.length > 0 && (
                <ProductSection
                    title="Sản phẩm hot"
                    subtitle="Đang được tìm kiếm nhiều nhất"
                    products={hotProducts}
                    viewAllLink="/shop?hot=true"
                    onAddToCart={handleAddToCart}
                />
            )}

            {/* Sản phẩm mới */}
            {newProducts.length > 0 && (
                <ProductSection
                    title="Sản phẩm mới"
                    subtitle="Vừa ra mắt tại TechZone"
                    products={newProducts}
                    viewAllLink="/shop?new=true"
                    onAddToCart={handleAddToCart}
                />
            )}

            {/* Sản phẩm đề xuất */}
            {recommendedProducts.length > 0 && (
                <ProductSection
                    title="Có thể bạn sẽ thích"
                    products={recommendedProducts}
                    viewAllLink="/shop?recommended=true"
                    onAddToCart={handleAddToCart}
                />
            )}
        </div>
    )
}
