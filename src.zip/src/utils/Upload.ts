import axios from 'axios'

// Hàm tải lên hình ảnh
export const uploadImage = async (file: File): Promise<string> => {
    try {
        // Tạo FormData để gửi file
        const formData = new FormData()
        formData.append('file', file)

        // Gửi request đến API upload
        const response = await axios.post('/api/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        })

        // Kiểm tra kết quả
        if (response.data.success) {
            return response.data.url
        } else {
            throw new Error(
                response.data.message || 'Không thể tải lên hình ảnh',
            )
        }
    } catch (error) {
        console.error('Lỗi khi tải lên hình ảnh:', error)
        throw error
    }
}

// Hàm tải lên hình ảnh từ base64
export const uploadBase64Image = async (
    base64Image: string,
): Promise<string> => {
    try {
        // Gửi request đến API upload với dữ liệu base64
        const response = await axios.post('/api/upload', {
            image: base64Image,
        })

        // Kiểm tra kết quả
        if (response.data.success) {
            return response.data.url
        } else {
            throw new Error(
                response.data.message || 'Không thể tải lên hình ảnh',
            )
        }
    } catch (error) {
        console.error('Lỗi khi tải lên hình ảnh:', error)
        throw error
    }
}

// Hàm xóa hình ảnh
export const deleteImage = async (imageUrl: string): Promise<boolean> => {
    try {
        // Trích xuất public_id từ URL
        const urlParts = imageUrl.split('/')
        const filenameWithExtension = urlParts[urlParts.length - 1]
        const publicId = `products/${filenameWithExtension.split('.')[0]}`

        // Gửi request xóa hình ảnh
        const response = await axios.delete('/api/upload', {
            data: { public_id: publicId },
        })

        return response.data.success
    } catch (error) {
        console.error('Lỗi khi xóa hình ảnh:', error)
        return false
    }
}

// Chuyển đổi base64 thành File
export const base64ToFile = (dataUrl: string, filename: string): File => {
    const arr = dataUrl.split(',')
    const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/png'
    const bstr = atob(arr[1])
    let n = bstr.length
    const u8arr = new Uint8Array(n)

    while (n--) {
        u8arr[n] = bstr.charCodeAt(n)
    }

    return new File([u8arr], filename, { type: mime })
}
