'use client'

import type React from 'react'

import { useState, useMemo } from 'react'
import DataTable from 'react-data-table-component'
import {
    Search,
    Plus,
    Calendar,
    ArrowUp,
    ArrowDown,
    Save,
    Trash2,
} from 'lucide-react'
import StockAdjustmentModal from './components/stock-adjustment-modal'
import { Product } from '../../../types/product'

// Định nghĩa kiểu dữ liệu cho điều chỉnh kho
interface StockAdjustment {
    id: number
    date: string
    type: 'import' | 'export' | 'adjustment'
    reason: string
    products: StockAdjustmentProduct[]
    status: 'draft' | 'completed'
    createdBy: string
}

interface StockAdjustmentProduct {
    id: number
    productId: number
    productName: string
    quantity: number
    unit: string
    note?: string
}

// Dữ liệu mẫu
const initialAdjustments: StockAdjustment[] = [
    {
        id: 1,
        date: '17/04/2023',
        type: 'import',
        reason: 'Nhập hàng từ nhà cung cấp',
        products: [
            {
                id: 1,
                productId: 1,
                productName: 'iPhone 14 Pro Max 256GB',
                quantity: 50,
                unit: 'Chiếc',
            },
            {
                id: 2,
                productId: 4,
                productName: 'Dell XPS 13 Plus',
                quantity: 20,
                unit: 'Chiếc',
            },
        ],
        status: 'completed',
        createdBy: 'Nguyễn Văn Admin',
    },
    {
        id: 2,
        date: '18/04/2023',
        type: 'export',
        reason: 'Xuất hàng cho đơn hàng #ORD-001',
        products: [
            {
                id: 3,
                productId: 1,
                productName: 'iPhone 14 Pro Max 256GB',
                quantity: 2,
                unit: 'Chiếc',
            },
            {
                id: 4,
                productId: 4,
                productName: 'Dell XPS 13 Plus',
                quantity: 1,
                unit: 'Chiếc',
            },
        ],
        status: 'completed',
        createdBy: 'Trần Thị Bán Hàng',
    },
    {
        id: 3,
        date: '19/04/2023',
        type: 'adjustment',
        reason: 'Điều chỉnh tồn kho sau kiểm kê',
        products: [
            {
                id: 5,
                productId: 2,
                productName: 'Samsung Galaxy S23 Ultra',
                quantity: -5,
                unit: 'Chiếc',
                note: 'Hàng hỏng',
            },
            {
                id: 6,
                productId: 5,
                productName: 'iPad Pro 11 inch M2',
                quantity: 10,
                unit: 'Chiếc',
                note: 'Điều chỉnh tăng',
            },
        ],
        status: 'completed',
        createdBy: 'Lê Văn Kho',
    },
    {
        id: 4,
        date: '20/04/2023',
        type: 'import',
        reason: 'Nhập hàng từ nhà cung cấp',
        products: [
            {
                id: 7,
                productId: 11,
                productName: 'Canon EOS R6 Mark II',
                quantity: 30,
                unit: 'Chiếc',
            },
            {
                id: 8,
                productId: 12,
                productName: 'ASUS ROG Strix G15',
                quantity: 15,
                unit: 'Chiếc',
            },
        ],
        status: 'completed',
        createdBy: 'Lê Văn Kho',
    },
    {
        id: 5,
        date: '21/04/2023',
        type: 'export',
        reason: 'Xuất hàng cho đơn hàng #ORD-005',
        products: [
            {
                id: 9,
                productId: 11,
                productName: 'Canon EOS R6 Mark II',
                quantity: 2,
                unit: 'Chiếc',
            },
            {
                id: 10,
                productId: 12,
                productName: 'ASUS ROG Strix G15',
                quantity: 1,
                unit: 'Chiếc',
            },
        ],
        status: 'draft',
        createdBy: 'Trần Thị Bán Hàng',
    },
]

// Danh sách sản phẩm mẫu
const sampleProducts: Product[] = [
    {
        id: 1,
        name: 'iPhone 14 Pro Max 256GB',
        category: 'Điện thoại',
        unit: 'Chiếc',
        price: 28990000,
        stock: 67,
        status: 'in-stock',
        image: '',
        description: 'iPhone 14 Pro Max 256GB chính hãng VN/A',
        barcode: '8936082080018',
        costPrice: 26000000,
        createdAt: '',
    },
    {
        id: 2,
        name: 'Samsung Galaxy S23 Ultra',
        category: 'Điện thoại',
        unit: 'Chiếc',
        price: 23990000,
        stock: 0,
        status: 'out-of-stock',
        image: '',
        description: 'Samsung Galaxy S23 Ultra 256GB chính hãng',
        barcode: '8936082080025',
        costPrice: 21000000,
        createdAt: '',
    },
    {
        id: 4,
        name: 'Dell XPS 13 Plus',
        category: 'Laptop',
        unit: 'Chiếc',
        price: 39990000,
        stock: 8,
        status: 'in-stock',
        image: '',
        description: 'Dell XPS 13 Plus i7-1260P 16GB RAM 512GB SSD',
        barcode: '8936082080049',
        costPrice: 36000000,
        createdAt: '',
    },
    {
        id: 5,
        name: 'iPad Pro 11 inch M2',
        category: 'Máy tính bảng',
        unit: 'Chiếc',
        price: 22990000,
        stock: 0,
        status: 'out-of-stock',
        image: '',
        description: 'iPad Pro 11 inch M2 WiFi 128GB',
        barcode: '8936082080056',
        costPrice: 20000000,
        createdAt: '',
    },
    {
        id: 11,
        name: 'Canon EOS R6 Mark II',
        category: 'Máy ảnh',
        unit: 'Chiếc',
        price: 59990000,
        stock: 3,
        status: 'in-stock',
        image: '',
        description: 'Máy ảnh Canon EOS R6 Mark II Body',
        barcode: '8936082080117',
        costPrice: 55000000,
        createdAt: '',
    },
    {
        id: 12,
        name: 'ASUS ROG Strix G15',
        category: 'Laptop',
        unit: 'Chiếc',
        price: 32990000,
        stock: 15,
        status: 'in-stock',
        image: '',
        description: 'Laptop gaming ASUS ROG Strix G15 G513RM',
        barcode: '8936082080124',
        costPrice: 29000000,
        createdAt: '',
    },
]

export default function StockAdjustment() {
    const [adjustments, setAdjustments] =
        useState<StockAdjustment[]>(initialAdjustments)
    const [searchTerm, setSearchTerm] = useState('')
    const [filterType, setFilterType] = useState('all')
    const [filterStatus, setFilterStatus] = useState('all')
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [editingAdjustment, setEditingAdjustment] =
        useState<StockAdjustment | null>(null)
    const [resetPaginationToggle, setResetPaginationToggle] = useState(false)
    const [selectedRows, setSelectedRows] = useState<StockAdjustment[]>([])

    // Xử lý tìm kiếm
    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value
        setSearchTerm(value)
        setResetPaginationToggle(!resetPaginationToggle)
    }

    // Mở modal thêm điều chỉnh kho mới
    const handleAddAdjustment = () => {
        setEditingAdjustment(null)
        setIsModalOpen(true)
    }

    // Mở modal chỉnh sửa điều chỉnh kho
    const handleEditAdjustment = (adjustment: StockAdjustment) => {
        setEditingAdjustment(adjustment)
        setIsModalOpen(true)
    }

    // Xử lý xóa điều chỉnh kho
    const handleDeleteAdjustment = (id: number) => {
        if (
            window.confirm(
                'Bạn có chắc chắn muốn xóa điều chỉnh kho này không?',
            )
        ) {
            setAdjustments(
                adjustments.filter((adjustment) => adjustment.id !== id),
            )
        }
    }

    // Lọc dữ liệu dựa trên loại, trạng thái và tìm kiếm
    const filteredData = useMemo(() => {
        let filtered = [...adjustments]

        // Lọc theo loại
        if (filterType !== 'all') {
            filtered = filtered.filter(
                (adjustment) => adjustment.type === filterType,
            )
        }

        // Lọc theo trạng thái
        if (filterStatus !== 'all') {
            filtered = filtered.filter(
                (adjustment) => adjustment.status === filterStatus,
            )
        }

        // Lọc theo từ khóa tìm kiếm
        if (searchTerm) {
            const searchLower = searchTerm.toLowerCase()
            filtered = filtered.filter(
                (adjustment) =>
                    adjustment.reason.toLowerCase().includes(searchLower) ||
                    adjustment.products.some((product) =>
                        product.productName.toLowerCase().includes(searchLower),
                    ),
            )
        }

        return filtered
    }, [adjustments, filterType, filterStatus, searchTerm])

    // Cấu hình cột cho DataTable
    const columns = [
        {
            name: 'Ngày',
            selector: (row: StockAdjustment) => row.date,
            sortable: true,
        },
        {
            name: 'Loại',
            selector: (row: StockAdjustment) => row.type,
            sortable: true,
            cell: (row: StockAdjustment) => {
                let typeClass = ''
                let typeText = ''
                let icon = null

                switch (row.type) {
                    case 'import':
                        typeClass = 'bg-green-100 text-green-600'
                        typeText = 'Nhập kho'
                        icon = <ArrowDown size={14} className="mr-1" />
                        break
                    case 'export':
                        typeClass = 'bg-blue-100 text-blue-600'
                        typeText = 'Xuất kho'
                        icon = <ArrowUp size={14} className="mr-1" />
                        break
                    case 'adjustment':
                        typeClass = 'bg-amber-100 text-amber-600'
                        typeText = 'Điều chỉnh'
                        break
                }

                return (
                    <span
                        className={`flex items-center rounded-full px-3 py-1 text-xs font-medium ${typeClass}`}
                    >
                        {icon} {typeText}
                    </span>
                )
            },
        },
        {
            name: 'Lý do',
            selector: (row: StockAdjustment) => row.reason,
            sortable: true,
        },
        {
            name: 'Số sản phẩm',
            selector: (row: StockAdjustment) => row.products.length,
            sortable: true,
        },
        {
            name: 'Trạng thái',
            selector: (row: StockAdjustment) => row.status,
            sortable: true,
            cell: (row: StockAdjustment) => {
                const statusClass =
                    row.status === 'completed'
                        ? 'bg-green-100 text-green-600'
                        : 'bg-yellow-100 text-yellow-600'
                const statusText =
                    row.status === 'completed' ? 'Hoàn thành' : 'Nháp'

                return (
                    <span
                        className={`rounded-full px-3 py-1 text-xs font-medium ${statusClass}`}
                    >
                        {statusText}
                    </span>
                )
            },
        },
        {
            name: 'Người tạo',
            selector: (row: StockAdjustment) => row.createdBy,
            sortable: true,
        },
        {
            name: '',
            cell: (row: StockAdjustment) => (
                <div className="flex space-x-2">
                    {row.status === 'draft' && (
                        <>
                            <button
                                className="text-blue-500 hover:text-blue-700"
                                onClick={() => handleEditAdjustment(row)}
                                title="Chỉnh sửa"
                            >
                                <Save size={16} />
                            </button>
                            <button
                                className="text-red-500 hover:text-red-700"
                                onClick={() => handleDeleteAdjustment(row.id)}
                                title="Xóa"
                            >
                                <Trash2 size={16} />
                            </button>
                        </>
                    )}
                </div>
            ),
            button: true,
            width: '100px',
        },
    ]

    // Tùy chỉnh style cho DataTable
    const customStyles = {
        headRow: {
            style: {
                backgroundColor: '#f9fafb',
                borderBottom: '1px solid #e5e7eb',
                fontSize: '0.75rem',
                color: '#6b7280',
                textTransform: 'uppercase' as const,
                fontWeight: '600',
                letterSpacing: '0.05em',
            },
        },
        rows: {
            style: {
                minHeight: '56px',
                fontSize: '0.875rem',
                color: '#111827',
                '&:hover': {
                    backgroundColor: '#f9fafb',
                },
            },
            stripedStyle: {
                backgroundColor: '#f9fafb',
            },
        },
        pagination: {
            style: {
                borderTop: '1px solid #e5e7eb',
                fontSize: '0.875rem',
            },
            pageButtonsStyle: {
                color: '#6b7280',
                fill: '#6b7280',
                '&:hover:not(:disabled)': {
                    backgroundColor: '#f3f4f6',
                },
                '&:focus': {
                    outline: 'none',
                },
            },
        },
    }

    // Tùy chỉnh component phân trang
    const paginationComponentOptions = {
        rowsPerPageText: 'Số hàng:',
        rangeSeparatorText: 'trên',
        selectAllRowsItem: true,
        selectAllRowsItemText: 'Tất cả',
    }

    return (
        <div className="p-6">
            <div className="mb-6">
                <h1 className="text-2xl font-semibold text-gray-800">
                    Điều chỉnh kho
                </h1>
                <div className="flex items-center text-sm text-gray-500">
                    <span>Trang chủ</span>
                    <span className="mx-2">•</span>
                    <span>Quản lý kho</span>
                    <span className="mx-2">•</span>
                    <span>Điều chỉnh kho</span>
                </div>
            </div>

            <div className="rounded-lg bg-white p-6 shadow-sm">
                <div className="mb-6 flex items-center justify-between">
                    <h2 className="text-lg font-medium">
                        Danh sách điều chỉnh kho
                    </h2>
                    <div className="flex space-x-2">
                        <button
                            className="flex items-center rounded-md bg-teal-500 px-4 py-2 text-white hover:bg-teal-600"
                            onClick={handleAddAdjustment}
                        >
                            <Plus size={16} className="mr-1" /> Tạo điều chỉnh
                        </button>
                    </div>
                </div>

                <div className="mb-6 flex flex-col justify-between space-y-4 md:flex-row md:space-y-0">
                    <div className="relative w-full md:w-80">
                        <div className="absolute top-1/2 left-3 -translate-y-1/2 transform text-gray-400">
                            <Search size={16} />
                        </div>
                        <input
                            placeholder="Tìm kiếm điều chỉnh kho"
                            className="w-full rounded-md border border-gray-300 py-2 pr-4 pl-10 focus:border-transparent focus:ring-2 focus:ring-teal-500 focus:outline-none"
                            value={searchTerm}
                            onChange={handleSearch}
                        />
                    </div>
                    <div className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2">
                        <div className="flex items-center">
                            <span className="mr-2 text-sm text-gray-500">
                                Loại:
                            </span>
                            <select
                                className="w-full rounded-md border border-gray-300 px-3 py-2 focus:border-transparent focus:ring-2 focus:ring-teal-500 focus:outline-none md:w-40"
                                value={filterType}
                                onChange={(e) => setFilterType(e.target.value)}
                            >
                                <option value="all">Tất cả</option>
                                <option value="import">Nhập kho</option>
                                <option value="export">Xuất kho</option>
                                <option value="adjustment">Điều chỉnh</option>
                            </select>
                        </div>
                        <div className="flex items-center">
                            <span className="mr-2 text-sm text-gray-500">
                                Trạng thái:
                            </span>
                            <select
                                className="w-full rounded-md border border-gray-300 px-3 py-2 focus:border-transparent focus:ring-2 focus:ring-teal-500 focus:outline-none md:w-40"
                                value={filterStatus}
                                onChange={(e) =>
                                    setFilterStatus(e.target.value)
                                }
                            >
                                <option value="all">Tất cả</option>
                                <option value="completed">Hoàn thành</option>
                                <option value="draft">Nháp</option>
                            </select>
                        </div>
                        <button className="flex items-center justify-center rounded-md border border-gray-300 px-4 py-2 hover:bg-gray-50">
                            <Calendar size={16} className="mr-2" />
                            <span>Thời gian</span>
                        </button>
                    </div>
                </div>

                <div className="overflow-hidden rounded-lg border">
                    <DataTable
                        columns={columns}
                        data={filteredData}
                        pagination
                        paginationResetDefaultPage={resetPaginationToggle}
                        paginationComponentOptions={paginationComponentOptions}
                        selectableRows
                        onSelectedRowsChange={(state) =>
                            setSelectedRows(state.selectedRows)
                        }
                        customStyles={customStyles}
                        noDataComponent={
                            <div className="p-4 text-center text-gray-500">
                                Không có điều chỉnh kho nào
                            </div>
                        }
                        persistTableHead
                    />
                </div>
            </div>

            {isModalOpen && (
                <StockAdjustmentModal
                    isOpen={isModalOpen}
                    onClose={() => setIsModalOpen(false)}
                    adjustment={editingAdjustment}
                    onSave={(adjustment) => {
                        if (adjustment.id) {
                            setAdjustments(
                                adjustments.map((a) =>
                                    a.id === Number(adjustment.id)
                                        ? {
                                              ...adjustment,
                                              id: Number(adjustment.id),
                                              products: adjustment.products.map(
                                                  (product) => ({
                                                      ...product,
                                                      productId: Number(
                                                          product.productId,
                                                      ),
                                                  }),
                                              ),
                                          }
                                        : a,
                                ),
                            )
                        } else {
                            const newId =
                                Math.max(...adjustments.map((a) => a.id), 0) + 1
                            setAdjustments([
                                ...adjustments,
                                {
                                    ...adjustment,
                                    id: Number(newId),
                                    date: new Date().toLocaleDateString(
                                        'vi-VN',
                                    ),
                                    createdBy: 'Nguyễn Văn Admin',
                                    products: adjustment.products.map(
                                        (product) => ({
                                            ...product,
                                            productId: Number(
                                                product.productId,
                                            ),
                                        }),
                                    ),
                                },
                            ])
                        }
                        setIsModalOpen(false)
                    }}
                    products={sampleProducts}
                />
            )}
        </div>
    )
}
