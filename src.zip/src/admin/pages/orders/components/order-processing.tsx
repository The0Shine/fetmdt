'use client'

import { useState } from 'react'
import { mainRepository } from '../../../../utils/Repository'

interface OrderProcessingProps {
    orderId: string
    currentStatus: 'pending' | 'processing' | 'completed' | 'cancelled'
    onStatusChange: (
        status: 'pending' | 'processing' | 'completed' | 'cancelled',
    ) => void
}

// Thêm interface cho API response
interface StatusResponse {
    success: boolean
    message?: string
    data?: any
}

export default function OrderProcessing({
    orderId,
    currentStatus,
    onStatusChange,
}: OrderProcessingProps) {
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState<string | null>(null)

    const updateOrderStatus = async (
        status: 'pending' | 'processing' | 'completed' | 'cancelled',
    ) => {
        if (status === currentStatus) return
        onStatusChange(status)
    }

    const steps = [
        {
            id: 'pending',
            name: 'Chờ xác nhận',
            description: 'Đơn hàng đã được tạo',
        },
        {
            id: 'processing',
            name: 'Đang xử lý',
            description: 'Đơn hàng đang được chuẩn bị',
        },
        {
            id: 'completed',
            name: 'Hoàn thành',
            description: 'Đơn hàng đã giao thành công',
        },
    ]

    return (
        <div className="mb-6 rounded-lg bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-lg font-medium">Trạng thái đơn hàng</h2>

            {error && (
                <div className="mb-4 rounded-md bg-red-50 p-3 text-red-600">
                    {error}
                </div>
            )}

            <div className="relative">
                <div className="absolute top-0 left-4 h-full w-0.5 bg-gray-200"></div>

                <div className="space-y-6">
                    {steps.map((step, index) => {
                        const isActive =
                            currentStatus === step.id ||
                            (currentStatus === 'completed' &&
                                ['pending', 'processing'].includes(step.id)) ||
                            (currentStatus === 'processing' &&
                                step.id === 'pending')
                        const isCurrentStep = currentStatus === step.id

                        return (
                            <div key={step.id} className="relative">
                                <div
                                    className={`absolute top-0 left-4 mt-1.5 -ml-2 h-4 w-4 rounded-full border ${
                                        isActive
                                            ? 'border-teal-500 bg-teal-500'
                                            : 'border-gray-300 bg-white'
                                    }`}
                                ></div>

                                <div className="ml-10">
                                    <h3
                                        className={`text-base font-semibold ${isActive ? 'text-teal-600' : 'text-gray-500'}`}
                                    >
                                        {step.name}
                                    </h3>
                                    <p className="text-sm text-gray-500">
                                        {step.description}
                                    </p>

                                    {!isCurrentStep && (
                                        <button
                                            onClick={() =>
                                                updateOrderStatus(
                                                    step.id as any,
                                                )
                                            }
                                            disabled={
                                                loading ||
                                                currentStatus === 'cancelled' ||
                                                (step.id === 'completed' &&
                                                    currentStatus ===
                                                        'pending') ||
                                                (isActive &&
                                                    step.id !== 'completed')
                                            }
                                            className={`mt-2 rounded-md px-3 py-1 text-xs font-medium ${
                                                isActive &&
                                                step.id !== 'completed'
                                                    ? 'cursor-not-allowed bg-gray-100 text-gray-500'
                                                    : 'bg-teal-100 text-teal-700 hover:bg-teal-200'
                                            }`}
                                        >
                                            {loading
                                                ? 'Đang cập nhật...'
                                                : 'Cập nhật trạng thái'}
                                        </button>
                                    )}
                                </div>
                            </div>
                        )
                    })}

                    {/* Cancelled status */}
                    <div className="relative">
                        <div
                            className={`absolute top-0 left-4 mt-1.5 -ml-2 h-4 w-4 rounded-full border ${
                                currentStatus === 'cancelled'
                                    ? 'border-red-500 bg-red-500'
                                    : 'border-gray-300 bg-white'
                            }`}
                        ></div>

                        <div className="ml-10">
                            <h3
                                className={`text-base font-semibold ${
                                    currentStatus === 'cancelled'
                                        ? 'text-red-600'
                                        : 'text-gray-500'
                                }`}
                            >
                                Đã hủy
                            </h3>
                            <p className="text-sm text-gray-500">
                                Đơn hàng đã bị hủy
                            </p>

                            {currentStatus !== 'cancelled' &&
                                currentStatus !== 'completed' && (
                                    <button
                                        onClick={() =>
                                            updateOrderStatus('cancelled')
                                        }
                                        disabled={loading}
                                        className="mt-2 rounded-md bg-red-100 px-3 py-1 text-xs font-medium text-red-700 hover:bg-red-200"
                                    >
                                        {loading
                                            ? 'Đang cập nhật...'
                                            : 'Hủy đơn hàng'}
                                    </button>
                                )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
